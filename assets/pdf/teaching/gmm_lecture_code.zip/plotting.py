import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

plt.style.use('ggplot')


def make_colormap(sequence):
    """
    Returns a LinearSegmentedColormap spanning the sequence of colors provided.

    :param sequence: A sequence of floats and RGB-tuples. The floats should be increasing
                     and they should lie in the interval (0,1).
    :returns:        A LinearSegmentedColormap spanning the sequence of colors provided.
    """
    sequence = [(None,) * 3, 0.0] + list(sequence) + [1.0, (None,) * 3]
    color_dictionary = {'red': [], 'green': [], 'blue': []}
    for i, item in enumerate(sequence):
        if isinstance(item, float):
            red1, green1, blue1 = sequence[i - 1]
            red2, green2, blue2 = sequence[i + 1]
            color_dictionary['red'].append([item, red1, red2])
            color_dictionary['green'].append([item, green1, green2])
            color_dictionary['blue'].append([item, blue1, blue2])
    return mcolors.LinearSegmentedColormap('CustomMap', color_dictionary)


def plot_observations(observations, title, colors='black', save_filename=None):
    # First we create the color map we are going to be using for all of our plots
    red_color = (0.2118, 0.4902, 0.6353)
    blue_color = (0.8118, 0.1373, 0.1686)
    colormap = make_colormap((red_color, blue_color))
    # Now we make the actual plot
    plt.scatter(observations[0, :], observations[1, :], s=40, c=colors, cmap=colormap, edgecolors='none')
    plt.title(title, y=1.05)
    if save_filename is not None:
        plt.savefig(save_filename, facecolor='white', bbox_inches='tight')
    plt.show()