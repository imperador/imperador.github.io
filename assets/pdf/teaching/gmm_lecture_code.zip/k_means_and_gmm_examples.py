import numpy as np
import plotting
import kmeans
import gmm

number_of_data_points = 200

# We first generate some random observations
observations_1 = np.random.multivariate_normal([5, 5], np.eye(2), int(number_of_data_points / 2)).T  # Sample from a Normal with mean (5,5) and identity covariance
observations_2 = np.random.multivariate_normal([10, 5], np.eye(2), int(number_of_data_points / 2)).T # Sample from a Normal with mean (10,5) and identity covariance
observations = np.concatenate((observations_1, observations_2), axis=1)	  # Concatenate our observations into a single array
correct_assignments = np.concatenate((np.zeros((1, int(number_of_data_points / 2))), np.ones((1, int(number_of_data_points / 2)))))

# Plot the data with the correct cluster assignments
plotting.plot_observations(observations, 'Data Set with Correct Cluster Assignments', correct_assignments, save_filename='labeled_data_set.pdf')
# Plot what our clustering algorithm actually observes
plotting.plot_observations(observations, 'Data Set as Observed by Clustering Algorithm', save_filename='unlabeled_data_set.pdf')

# K-Means examples
# Let's start by setting the number of desired clusters to 2
kmeans_model = kmeans.KMeans(observations, number_of_clusters=2, initialization_method=kmeans.InitializationMethod.random, plot_results=True, save_results=False)
kmeans_model.run(100)
# Let's continue by setting the number of desired clusters to 4
kmeans_model = kmeans.KMeans(observations, number_of_clusters=4, initialization_method=kmeans.InitializationMethod.kmeans_plus_plus, plot_results=True, save_results=False)
kmeans_model.run(100)

# GMM examples
# Let's start by setting the number of desired clusters to 2
gmm = gmm.GMM(observations, initialization_method=gmm.InitializationMethod.random, number_of_clusters=2, plot_results=True, save_results=True)
gmm.run(100)
# Let's continue by setting the number of desired clusters to 4
gmm = gmm.GMM(observations, initialization_method=gmm.InitializationMethod.random, number_of_clusters=4, plot_results=True, save_results=False)
gmm.run(100)