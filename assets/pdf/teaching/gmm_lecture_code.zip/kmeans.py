__author__ = 'Emmanouil Antonios Platanios'

import numpy as np
import matplotlib.pyplot as plt
import plotting
from enum import Enum


class KMeans:
    """
    Example class implementing a k-means model. Note that the implementation is not optimized -- it is intended for
    educational purposes within the context of a class.
    """

    def __init__(self, observations, number_of_clusters, initialization_method, plot_results=False, save_results=False):
        """
        Initializes the k-means class.

        :param observations: An array containing all the observations. The first dimension corresponds to the
                             dimensionality of the observations and the second to the number of observations.
        :param plot_results: A boolean value indicating whether or not to plot the results while running experiments.
        :param save_results: A boolean value indicating whether or not to save the resulting plots while running
                             experiments.
        """
        self.observations = observations
        self.dimensionality = observations.shape[0]
        self.number_of_observations = observations.shape[1]
        self.number_of_clusters = number_of_clusters
        self.initialization_method = initialization_method
        self.plot_results = plot_results
        self.save_results = save_results
        self.means = initialization_method.initialize(observations, number_of_clusters)
        self.responsibilities = np.zeros((number_of_clusters, self.number_of_observations))
        self.e_step()

    def e_step(self):
        """
        Performs the expectation step (i.e., E-step) of the EM algorithm for k-means. This step involves computing the
        cluster assignment for each observation, using the cluster mean that is closest to it.
        """
        for n in np.arange(self.number_of_observations):
            closest_mean = min([(k, np.linalg.norm(self.observations[:, n] - self.means[k, :])) \
                                for k in np.arange(self.means.shape[0])], key=lambda t: t[1])[0]
            self.responsibilities[:, n] = 0
            self.responsibilities[closest_mean, n] = 1

    def m_step(self):
        """
        Performs the maximization step (i.e., M-step) of the EM algorithm for k-means. This step involves computing the
        mean for each cluster by averaging all of the observations that have been assigned to that cluster.
        """
        for k in np.arange(self.number_of_clusters):
            effective_number_of_observations = 0
            self.means[k, :] = np.zeros(self.dimensionality)
            for n in np.arange(self.number_of_observations):
                effective_number_of_observations += self.responsibilities[k, n]
                self.means[k, :] += self.responsibilities[k, n] * self.observations[:, n]
            self.means[k, :] /= effective_number_of_observations

    def run(self, maximum_number_of_iterations=100):
        """
        Runs the example k-means experiment.

        :param maximum_number_of_iterations: The maximum number of iterations allowed.
        """
        iteration = 1
        converged = False
        while not converged:
            previous_means = np.array(self.means)
            self.plot(iteration)
            self.e_step()
            self.m_step()
            if iteration >= maximum_number_of_iterations \
                    or np.linalg.norm(self.means - previous_means) < 1e-10:
                converged = True
            iteration += 1
        if self.plot_results:
            plt.show()

    def plot(self, iteration):
        """
        Plots the current k-means results. The plot includes the responsibility values for all data points along with
        the means of all clusters.
        """
        plt.figure(iteration)
        red_color = (0.2118, 0.4902, 0.6353)
        blue_color = (0.8118, 0.1373, 0.1686)
        colormap = plotting.make_colormap((red_color, blue_color))
        colors = []
        for n in np.arange(self.number_of_observations):
            colors.append(np.inner(self.responsibilities[:, n], np.linspace(0, 1, num=self.number_of_clusters)))
        plt.scatter(self.observations[0, :], self.observations[1, :], s=40, c=colors, cmap=colormap, edgecolors='none')
        plt.scatter(self.means[:, 0], self.means[:, 1], s=200, c='black', marker='+', linewidth='5')
        plt.title(self.initialization_method.plot_title_prefix() + ' Iteration ' + str(iteration), y=1.05)
        if self.save_results:
            plt.savefig(self.initialization_method.filename_prefix() + '_iteration_' + str(iteration) + '.pdf',
                        facecolor='white', bbox_inches='tight')


class InitializationMethod(Enum):
    bad = 1
    random = 2
    kmeans_plus_plus = 3

    def initialize(self, observations, number_of_clusters):
        if self is InitializationMethod.bad:
            return self.bad_initialization(observations, number_of_clusters)
        elif self is InitializationMethod.random:
            return self.random_initialization(observations, number_of_clusters)
        elif self is InitializationMethod.kmeans_plus_plus:
            return self.kmeans_plus_plus_initialization(observations, number_of_clusters)
        else:
            raise ValueError('The provided k-means initialization method is invalid.')

    def plot_title_prefix(self):
        if self is InitializationMethod.bad:
            return 'K-Means'
        elif self is InitializationMethod.random:
            return 'K-Means'
        elif self is InitializationMethod.kmeans_plus_plus:
            return 'K-Means++'
        else:
            raise ValueError('The provided k-means initialization method is invalid.')

    def filename_prefix(self):
        if self is InitializationMethod.bad:
            return 'kmeans_bad'
        elif self is InitializationMethod.random:
            return 'kmeans_random'
        elif self is InitializationMethod.kmeans_plus_plus:
            return 'kmeans_pp'
        else:
            raise ValueError('The provided k-means initialization method is invalid.')

    @staticmethod
    def bad_initialization(observations, number_of_clusters):
        return observations[:, np.arange(number_of_clusters)].T

    @staticmethod
    def random_initialization(observations, number_of_clusters):
        observation_indexes = np.random.choice(number_of_clusters, replace=False, size=number_of_clusters)
        return observations[:, observation_indexes].T

    @staticmethod
    def kmeans_plus_plus_initialization(observations, number_of_clusters):
        centroids = np.ndarray((observations.shape[0], 1))
        centroids[:, 0] = observations[:, np.random.randint(low=0, high=observations.shape[1])]
        while centroids.shape[1] < number_of_clusters:
            probabilities = np.zeros(observations.shape[1])
            for observation_index in np.arange(0, observations.shape[1]):
                probabilities[observation_index] = \
                min([(i, np.linalg.norm(observations[:, observation_index] - centroids[:, i]) ** 2) \
                     for i in np.arange(centroids.shape[1])], key=lambda t: t[1])[1]
            probabilities = probabilities / probabilities.sum()
            cumulative_probabilities = probabilities.cumsum()
            uniform_random = np.random.uniform()
            centroids = np.column_stack(
                (centroids, observations[:, np.where(cumulative_probabilities >= uniform_random)[0][0]]))
        return centroids.T
