__author__ = 'Emmanouil Antonios Platanios'

import numpy as np
import matplotlib.pyplot as plt
import plotting
from scipy.stats import multivariate_normal
from enum import Enum


class GMM:
    """
    Example class implementing a Gaussian Mixture Model (GMM). Note that the implementation is not optimized -- it is
    intended for educational purposes within the context of a class.
    """

    def __init__(self, observations, number_of_clusters, initialization_method, plot_results=False, save_results=False):
        """
        Initializes the GMM class.

        :param observations: An array containing all the observations. The first dimension corresponds to the
                             dimensionality of the observations and the second to the number of observations.
        :param number_of_clusters: The number of clusters to use.
        :param plot_results: A boolean value indicating whether or not to plot the results while running experiments.
        :param save_results: A boolean value indicating whether or not to save the resulting plots while running
                             experiments.
        """
        self.observations = observations
        self.dimensionality = observations.shape[0]
        self.number_of_observations = observations.shape[1]
        self.number_of_clusters = number_of_clusters
        self.plot_results = plot_results
        self.save_results = save_results
        self.mixing_coefficients = np.random.rand(number_of_clusters)
        self.mixing_coefficients /= np.sum(self.mixing_coefficients)
        self.means = initialization_method.initialize(observations, number_of_clusters)
        self.covariances = np.zeros((number_of_clusters, self.dimensionality, self.dimensionality))
        for k in np.arange(number_of_clusters):
            self.covariances[k, :, :] = np.eye(self.dimensionality)
        self.responsibilities = np.zeros((number_of_clusters, self.number_of_observations))
        self.e_step()

    def e_step(self):
        """
        Performs the expectation step (i.e., E-step) of the EM algorithm for GMM.
        """
        for n in np.arange(self.number_of_observations):
            for k in np.arange(self.number_of_clusters):
                self.responsibilities[k, n] = multivariate_normal.pdf(self.observations[:, n],
                                                                      mean=self.means[k, :],
                                                                      cov=self.covariances[k, :, :])
            self.responsibilities[:, n] /= np.sum(self.responsibilities[:, n])

    def m_step(self):
        """
        Performs the maximization step (i.e., M-step) of the EM algorithm for GMM.
        """
        for k in np.arange(self.number_of_clusters):
            effective_number_of_observations = 0
            self.means[k, :] = np.zeros(self.dimensionality)
            for n in np.arange(self.number_of_observations):
                effective_number_of_observations += self.responsibilities[k, n]
                self.means[k, :] += self.responsibilities[k, n] * self.observations[:, n]
            self.means[k, :] /= effective_number_of_observations
            self.covariances[k, :, :] = np.zeros((self.dimensionality, self.dimensionality))
            for n in np.arange(self.number_of_observations):
                temporary = self.observations[:, n] - self.means[k, :]
                self.covariances[k, :, :] += self.responsibilities[k, n] * np.outer(temporary, temporary)
            self.covariances[k, :, :] /= effective_number_of_observations
            self.mixing_coefficients[k] = effective_number_of_observations / self.number_of_observations

    def log_likelihood(self):
        """
        Computes the log-likelihood using the current model parameters and all of the provided observations.

        :returns: The log-likelihood value.
        """
        log_likelihood = 0
        for n in np.arange(self.number_of_observations):
            log_likelihood_term = 0
            for k in np.arange(self.number_of_clusters):
                log_likelihood_term += self.mixing_coefficients[k] * multivariate_normal.pdf(self.observations[:, n],
                                                                                             mean=self.means[k, :],
                                                                                             cov=self.covariances[k, :, :])
            log_likelihood += np.log(log_likelihood_term)
        return log_likelihood

    def run(self, maximum_number_of_iterations=100):
        """
        Runs the example GMM experiment.

        :param maximum_number_of_iterations: The maximum number of iterations allowed.
        """
        current_log_likelihood = self.log_likelihood()
        iteration = 1
        converged = False
        while not converged:
            self.plot(iteration)
            self.e_step()
            self.m_step()
            previous_log_likelihood = current_log_likelihood
            current_log_likelihood = self.log_likelihood()
            if iteration >= maximum_number_of_iterations \
                    or np.abs(current_log_likelihood - previous_log_likelihood) < 1e-3:
                converged = True
            iteration += 1
        if self.plot_results:
            plt.show()

    def plot(self, iteration):
        """
        Plots the current GMM results. The plot includes the responsibility values for all data points, along with a
        visualization of the current Gaussian distributions.
        """
        plt.figure(iteration)
        red_color = (0.2118, 0.4902, 0.6353)
        blue_color = (0.8118, 0.1373, 0.1686)
        colormap = plotting.make_colormap((red_color, blue_color))
        colors = []
        for n in np.arange(self.number_of_observations):
            colors.append(np.inner(self.responsibilities[:, n], np.linspace(0, 1, num=self.number_of_clusters)))
        plt.scatter(self.observations[0, :], self.observations[1, :], s=40, c=colors, cmap=colormap, edgecolors='none')
        plt.title('GMM Iteration ' + str(iteration), y=1.05)
        x = np.arange(plt.xlim()[0], plt.xlim()[1], 0.025)
        y = np.arange(plt.ylim()[0], plt.ylim()[1], 0.025)
        X, Y = np.meshgrid(x, y)
        normals = []
        for k in np.arange(self.number_of_clusters):
            normals.append(plt.mlab.bivariate_normal(X, Y,
                                                     self.covariances[k, 0, 0], self.covariances[k, 1, 1],
                                                     self.means[k, 0], self.means[k, 1],
                                                     self.covariances[k, 0, 1]))
            color = k / (self.number_of_clusters - 1)
            temp = zip(tuple(color * i for i in blue_color), tuple((1 - color) * i for i in red_color))
            plt.contour(X, Y, normals[-1], 2, colors=[tuple(sum(x) for x in temp)], alpha=0.5, linewidths=3)
        if self.save_results:
            plt.savefig('gmm_iteration_' + str(iteration) + '.pdf', facecolor='white', bbox_inches='tight')


class InitializationMethod(Enum):
    bad = 1
    random = 2

    def initialize(self, observations, number_of_clusters):
        if self is InitializationMethod.bad:
            return self.bad_initialization(observations, number_of_clusters)
        elif self is InitializationMethod.random:
            return self.random_initialization(observations, number_of_clusters)
        else:
            raise ValueError('The provided GMM initialization method is invalid.')

    @staticmethod
    def bad_initialization(observations, number_of_clusters):
        means = np.zeros((number_of_clusters, observations.shape[0]))
        for k in np.arange(number_of_clusters):
            means[k, 1] = k * 10
        return means

    @staticmethod
    def random_initialization(observations, number_of_clusters):
        observation_indexes = np.random.choice(number_of_clusters, replace=False, size=number_of_clusters)
        return observations[:, observation_indexes].T